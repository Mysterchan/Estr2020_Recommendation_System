# ESTR2020 Project

Name: Chan Yuk Kit <br>
SID: 1155193356

There are three files in total within this zip file:

1. sgd_pmf.py
2. sgd_cpmf.py
3. MCMC_bpmf.py

The first two files contain implementations of stochastic gradient descent on the loss function derived from PMF and CPMF, respectively. The third file, as mentioned in my report, includes the implementation of MCMC and related algorithms.